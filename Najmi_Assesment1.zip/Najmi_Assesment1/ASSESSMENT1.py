#%%
""" github = https://github.com/najmi-hisham/CAPSTONE1-YPAI07"""
#%%
#setup
from time_series_helper import WindowGenerator

import os
import datetime

import IPython
import IPython.display
import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
import tensorflow as tf  

mpl.rcParams['figure.figsize'] = (8, 6)
mpl.rcParams['axes.grid'] = False


# %%
#  Load data
URL = 'https://raw.githubusercontent.com/MoH-Malaysia/covid19-public/main/epidemic/cases_malaysia.csv'
df = pd.read_csv(URL)
#train_dataset = pd.read_csv("2024_COVID_TRAIN_SET.csv")
#test_dataset = pd.read_csv("2024_COVID_TEST_SET.csv")
#%%
#Removing date from df and use '%d-%m-%Y' format and store in date
df['date'] = pd.to_datetime(df['date'])
df["date"] = df['date'].dt.strftime('%d-%m-%Y')
date = df.pop('date')
#%%
#Try to plot graph 'cases_new' vs date
plot_cols = 'cases_new'
plot_features = df[plot_cols]
plot_features.index = date
_ = plot_features.plot(subplots=True)
column_indices = {name: i for i, name in enumerate(df.columns)}

#%%
#ALL column non null
columns_to_keep = df.columns[:3]
df = df[columns_to_keep]

#%%
df = df.astype(int)
#%%
#Splitting
n = len(df)
train_dataset = df[0:int(n*0.7)]        #1019
val_dataset = df[int(n*0.7):int(n*0.9)] #292
test_dataset = df[int(n*0.9):]          #146

num_features = df.shape[1]

# %%
#Normalizing Data

train_mean = train_dataset.mean()
train_std = train_dataset.std()

train_df = (train_dataset - train_mean) / train_std
val_df = (val_dataset - train_mean) / train_std
test_df = (test_dataset - train_mean) / train_std
# %%
# Use WindowGenerator class
w1 = WindowGenerator(input_width=30, label_width=30, shift=1,
                     label_columns=['cases_new'],train_df=train_df,val_df=val_df,test_df=test_df)
# %%
# Create LSTM model
lstm_single_step = tf.keras.models.Sequential([
    # Shape [batch, time, features] => [batch, time, lstm_units]
    tf.keras.layers.LSTM(64, return_sequences=True),
    tf.keras.layers.Dropout(0.3),
    tf.keras.layers.LSTM(32, return_sequences=True),
    # Shape => [batch, time, features]
    tf.keras.layers.Dense(units=1)
])

#%%
PATH = os.getcwd()
logpath = os.path.join(PATH, "tensorboard_log", datetime.datetime.now().strftime("%Y%m%d-%H%M%S"))
tb_train = tf.keras.callbacks.TensorBoard(log_dir='./logs/train')
tb_test = tf.keras.callbacks.TensorBoard(log_dir='./logs/test')

#%%
#compile and fit function
def compile_and_fit(model, window, patience=3):
    early_stopping = tf.keras.callbacks.EarlyStopping(monitor='loss',
                                                      patience=patience,
                                                      mode='min')
    MAX_EPOCHS = 20
    model.compile(loss=tf.keras.losses.MeanSquaredError(),
                  optimizer=tf.keras.optimizers.Adam(),
                  metrics=[tf.keras.metrics.MeanAbsolutePercentageError()],
    )

    history = model.fit(window.train, epochs= MAX_EPOCHS,
                        validation_data=window.val,
                        callbacks=[early_stopping,tb_train])
    return history

#%%
# Training start
history = compile_and_fit(lstm_single_step , w1)

#%%
#Plot the graph for real vs prediction difference
# I take 31 data every plot : input:30 days and label:30 days with one shift in future
w1.plot(plot_col= 'cases_new', model = lstm_single_step)
# %%
train_loss_single = history.history['loss']
val_loss_single = history.history['val_loss']

plt.figure(figsize=(10, 6))
epochs = range(1, len(train_loss_single) + 1)
plt.plot(epochs, train_loss_single, label='Training Loss', marker='o')
plt.title('Training Loss')
plt.xlabel('Epoch')
plt.ylabel('Loss')
plt.legend()
plt.show()

#%%
#Get the model_architecture
from tensorflow.keras.utils import plot_model

plot_model(lstm_single_step, to_file='model_architecture.png', show_shapes=True)



#%%
#For test dataset training
def compile_and_fit_test(model, window, patience=4):
    early_stopping = tf.keras.callbacks.EarlyStopping(monitor='mean_absolute_percentage_error',
                                                      patience=patience,
                                                      mode='min')
    MAX_EPOCHS = 30
    model.compile(loss=tf.keras.losses.MeanSquaredError(),
                  optimizer=tf.keras.optimizers.Adam(),
                  metrics=[tf.keras.metrics.MeanAbsolutePercentageError()],
    )

    history = model.fit(window.test, epochs= MAX_EPOCHS,
                        callbacks=[early_stopping,tb_test])
    return history
    
history_test = compile_and_fit_test(lstm_single_step , w1)
#%%
#Plot MAPE
mape = history_test.history['mean_absolute_percentage_error']

plt.figure(figsize=(10, 6))
epochs = range(1, len(mape) + 1)
plt.plot(epochs, mape, label='MAPE', marker='o')
plt.title('mean_absolute_percentage_error for test')
plt.xlabel('Epoch')
plt.ylabel('mean')
plt.legend()
plt.show()
# %%
""" Conclusion:
    Model performace is okay based on the predicted vs real data even there is some points
    not well predicted. As for epoch loss we can see that there is good result but
    for MAPE, it was high and for the test the minimum that i can get is 16. I hope my result 
    can be considered.

    MAPE test:
    loss: 0.0029 - mean_absolute_percentage_error: 16.3891
    """
